<?php
// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Mulai session
session_start();

require_once 'config.php';
require_once 'functions.php';

// Set judul halaman
$page_title = "Kelola Kategori - Sistem Keuangan Gereja";

// DEBUG: Tampilkan error koneksi jika ada
if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

$action = isset($_GET['action']) ? $_GET['action'] : 'list';

// 1. Ambil semua data jurnal untuk dropdown
// Ganti kode pengambilan data jurnal dengan ini:
$jurnals = [];
$sql = "SELECT * FROM jurnal ORDER BY nama_jurnal";
$result = $conn->query($sql);

if ($result === false) {
    die("Error mengambil data jurnal: " . $conn->error);
}

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $jurnals[] = $row;
    }
} else {
    die("Tabel jurnal kosong. Silakan isi data jurnal terlebih dahulu.");
}

// DEBUG: Tampilkan data jurnal yang diambil
error_log("Data Jurnal: " . print_r($jurnals, true));

// 2. Ambil id_jurnal dari parameter URL
$selected_jurnal_id = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;

switch ($action) {
    case 'add_kategori':
        addKategori();
        break;
    case 'add_subkategori':
        addSubkategori();
        break;
    case 'save_kategori':
        saveKategori();
        break;
    case 'save_subkategori':
        saveSubkategori();
        break;
    case 'delete_kategori':
        deleteKategori();
        break;
    case 'delete_subkategori':
        deleteSubkategori();
        break;
    default:
        listData();
}
function listData() {
    global $conn, $jurnals, $selected_jurnal_id;
    
    $selected_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;
    
    // Ambil data kategori
    $kategori = [];
    $sql = "SELECT * FROM kategori";
    if ($selected_jurnal) {
        $sql .= " WHERE id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $selected_jurnal);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $kategori[] = $row;
        }
    }
    
    // Ambil data subkategori
    $subkategori = [];
    $sql = "SELECT s.*, k.nama_kategori, j.nama_jurnal 
            FROM subkategori s 
            JOIN kategori k ON s.id_kategori = k.id_kategori
            JOIN jurnal j ON k.id_jurnal = j.id_jurnal";
    if ($selected_jurnal) {
        $sql .= " WHERE k.id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $selected_jurnal);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    if ($result && $result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $subkategori[] = $row;
        }
    }
    
    // Pastikan view menerima semua variabel
    $view_data = [
        'jurnals' => $jurnals,
        'kategori' => $kategori,
        'subkategori' => $subkategori,
        'selected_jurnal_id' => $selected_jurnal_id
    ];
    
    // Debug sebelum include view
    error_log("Data ke View: " . print_r($view_data, true));
    
    // Include header
    include 'views/header.php';
    
    extract($view_data);
    include 'views/admin_kategori.php';
    
    // Include footer
    include 'views/footer.php';
}



function addKategori() {
    global $jurnals;
    
    // Include header
    include 'views/header.php';
    
    include 'views/form_kategori.php';
    
    // Include footer
    include 'views/footer.php';
}

function addSubkategori() {
    global $conn;
    
    // Ambil data kategori untuk dropdown berdasarkan jurnal yang dipilih (jika ada)
    $selected_jurnal = isset($_GET['id_jurnal']) ? intval($_GET['id_jurnal']) : null;
    
    $kategori = [];
    $sql = "SELECT * FROM kategori";
    
    if ($selected_jurnal) {
        $sql .= " WHERE id_jurnal = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $selected_jurnal);
        $stmt->execute();
        $result = $stmt->get_result();
    } else {
        $result = $conn->query($sql);
    }
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $kategori[] = $row;
        }
    }
    
    // Include header
    include 'views/header.php';
    
    include 'views/form_subkategori.php';
    
    // Include footer
    include 'views/footer.php';
}

function saveKategori() {
    global $conn;
    
    $id_jurnal = intval($_POST['id_jurnal']);
    $kode = trim($_POST['kode_kategori']);
    $nama = trim($_POST['nama_kategori']);
    
    // Validasi
    if (empty($id_jurnal) || empty($kode) || empty($nama)) {
        $_SESSION['error'] = "Semua field harus diisi";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Validasi format kode kategori (3 digit angka)
    if (!preg_match('/^[0-9]{3}$/', $kode)) {
        $_SESSION['error'] = "Kode kategori harus 3 digit angka (contoh: 100, 200, 300)";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Cek apakah kode sudah ada di jurnal yang sama
    $sql = "SELECT id_kategori FROM kategori WHERE kode_kategori = ? AND id_jurnal = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $kode, $id_jurnal);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Kode kategori sudah ada di jurnal ini";
        header("Location: admin_kategori.php?action=add_kategori");
        exit;
    }
    
    // Simpan ke database
    $sql = "INSERT INTO kategori (id_jurnal, kode_kategori, nama_kategori) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $id_jurnal, $kode, $nama);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Kategori berhasil ditambahkan";
    } else {
        $_SESSION['error'] = "Gagal menambahkan kategori: " . $conn->error;
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function saveSubkategori() {
    global $conn;
    
    $id_kategori = intval($_POST['id_kategori']);
    $kode = trim($_POST['kode_subkategori']);
    $nama = trim($_POST['nama_subkategori']);
    
    // Validasi
    if (empty($id_kategori) || empty($kode) || empty($nama)) {
        $_SESSION['error'] = "Semua field harus diisi";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }
    
    // Validasi format kode subkategori dengan pola yang lebih jelas
    // Format: xxx.xx.xx atau xxx.xx.xxx
    if (!preg_match('/^[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3})?$/', $kode)) {
        $_SESSION['error'] = "Format kode subkategori tidak valid. Harap gunakan pola: xxx.xx.xx atau xxx.xx.xxx (contoh: 100.01.01 atau 200.05.001). Pastikan hanya angka dan titik yang digunakan.";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }
    
    // Cek apakah kode sudah ada di kategori yang sama
    $sql = "SELECT id_subkategori FROM subkategori WHERE kode_subkategori = ? AND id_kategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $kode, $id_kategori);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Kode subkategori sudah ada di kategori ini";
        header("Location: admin_kategori.php?action=add_subkategori");
        exit;
    }
    
    // Simpan ke database
    $sql = "INSERT INTO subkategori (id_kategori, kode_subkategori, nama_subkategori) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $id_kategori, $kode, $nama);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Subkategori berhasil ditambahkan";
    } else {
        $_SESSION['error'] = "Gagal menambahkan subkategori: " . $conn->error;
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function deleteKategori() {
    global $conn;
    
    // Validasi ID
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        $_SESSION['error'] = "ID kategori tidak valid";
        header("Location: admin_kategori.php");
        exit;
    }
    
    $id = intval($_GET['id']);
    
    // Mulai transaksi
    $conn->begin_transaction();
    
    try {
        // 1. Hapus semua subkategori terkait terlebih dahulu
        $sql = "DELETE FROM subkategori WHERE id_kategori = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // 2. Hapus kategori
        $sql = "DELETE FROM kategori WHERE id_kategori = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        
        // Commit transaksi
        $conn->commit();
        
        $_SESSION['success'] = "Kategori dan semua subkategori terkait berhasil dihapus";
    } catch (Exception $e) {
        // Rollback jika ada error
        $conn->rollback();
        $_SESSION['error'] = "Gagal menghapus kategori: " . $e->getMessage();
    }
    
    header("Location: admin_kategori.php");
    exit;
}

function deleteSubkategori() {
    global $conn;
    
    // Validasi ID
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
        $_SESSION['error'] = "ID subkategori tidak valid";
        header("Location: admin_kategori.php");
        exit;
    }
    
    $id = intval($_GET['id']);
    
    // 1. Cek apakah subkategori digunakan di transaksi
    $sql = "SELECT COUNT(*) as total FROM transaksi WHERE id_subkategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    if ($row['total'] > 0) {
        $_SESSION['error'] = "Tidak dapat menghapus subkategori karena masih digunakan dalam transaksi";
        header("Location: admin_kategori.php");
        exit;
    }
    
    // 2. Hapus subkategori
    $sql = "DELETE FROM subkategori WHERE id_subkategori = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Subkategori berhasil dihapus";
    } else {
        $_SESSION['error'] = "Gagal menghapus subkategori: " . $conn->error;
    }
    
    header("Location: admin_kategori.php");
    exit;
}
?>
<?php
if (!isset($_SESSION['sheet3_report']) || empty($_SESSION['sheet3_report'])) {
    echo "<div class='alert alert-info'>Tidak ada data laporan. Silakan input data terlebih dahulu.</div>";
    return;
}

$report = $_SESSION['sheet3_report'];
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="bi bi-table me-2"></i>Laporan Horizontal (Sheet 3)
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Kategori</th>
                        <th>Kode Subkategori</th>
                        <th>Uraian</th>
                        <?php foreach ($report['bulan'] as $bulan): ?>
                            <th class="text-center"><?= htmlspecialchars($bulan) ?></th>
                        <?php endforeach; ?>
                        <th class="text-center">Total</th>
                        <th class="text-center">Anggaran Pendapatan</th>
                        <th class="text-center">Selisih</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $current_group = '';
                    $group_totals = array_fill_keys($report['bulan'], 0);
                    $overall_totals = array_fill_keys($report['bulan'], 0);
                    $tempTotalPerKelompok = [];
                    ?>
                    
                    <!-- Tampilkan Uang Setoran terlebih dahulu jika ada -->
                    <?php if (!empty($report['uang_setoran'])): ?>
                        <?php
                        $totalUangSetoran = 0;
                        ?>
                        <tr style="background-color: #c8ffc8;">
                            <td>Uang Setoran</td>
                            <td></td>
                            <td></td>
                            <?php foreach ($report['bulan'] as $bulan): 
                                $amount = isset($report['uang_setoran'][$bulan]) ? $report['uang_setoran'][$bulan] : 0;
                                $totalUangSetoran += $amount;
                                $overall_totals[$bulan] += $amount;
                            ?>
                                <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                            <?php endforeach; ?>
                            <td class="text-end fw-bold">Rp <?= number_format($totalUangSetoran, 0, ',', '.') ?></td>
                            <td class="text-end"></td>
                            <td class="text-end fw-bold">Rp <?= number_format($totalUangSetoran, 0, ',', '.') ?></td>
                        </tr>
                    <?php endif; ?>
                    
                    <!-- Proses kategori lainnya -->
                    <?php foreach ($report['all_categories'] as $kategori): ?>
                        <?php
                        // Skip Uang Setoran jika sudah diproses
                        if ($kategori == "Uang Setoran") continue;
                        
                        $kelompok = substr($kategori, 0, 3);
                        
                        // Inisialisasi total sementara per kelompok
                        if (!isset($tempTotalPerKelompok[$kelompok])) {
                            $tempTotalPerKelompok[$kelompok] = array_fill_keys($report['bulan'], 0);
                        }
                        
                        // Tampilkan total kelompok jika kelompok berubah
                        if ($kelompok !== $current_group && $current_group !== ''): ?>
                            <tr class="table-warning">
                                <td colspan="2"><strong>Total Kelompok <?= $current_group ?></strong></td>
                                <td></td>
                                <?php 
                                $group_total = 0;
                                foreach ($report['bulan'] as $bulan): 
                                    $amount = $tempTotalPerKelompok[$current_group][$bulan] ?? 0;
                                    $group_total += $amount;
                                ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($group_total, 0, ',', '.') ?></td>
                                <td class="text-end"></td>
                                <td class="text-end fw-bold">Rp <?= number_format($group_total, 0, ',', '.') ?></td>
                            </tr>
                        <?php endif;
                        
                        $current_group = $kelompok;
                        $hasDataInCategory = false;
                        ?>
                        
                        <!-- Tampilkan subkategori dalam kategori ini -->
                        <?php foreach ($report['all_sub_categories'][$kategori] as $subkategori): ?>
                            <?php
                            $hasData = false;
                            $sub_total = 0;
                            $anggaran_total = 0;
                            
                            // Cek apakah ada data untuk subkategori ini
                            foreach ($report['bulan'] as $bulan) {
                                $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                                if (isset($report['total_kas'][$uniqueKey]) && $report['total_kas'][$uniqueKey] > 0) {
                                    $hasData = true;
                                    break;
                                }
                            }
                            
                            if (!$hasData) continue;
                            $hasDataInCategory = true;
                            ?>
                            
                            <tr>
                                <td><?= htmlspecialchars($kategori) ?></td>
                                <td><?= htmlspecialchars($subkategori) ?></td>
                                <td><?= isset($report['uraian_dict'][$subkategori]) ? htmlspecialchars($report['uraian_dict'][$subkategori]) : 'Uraian Tidak Diketahui' ?></td>
                                <?php 
                                $sub_total = 0;
                                $anggaran_total = 0;
                                foreach ($report['bulan'] as $bulan): 
                                    $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                                    $amount = isset($report['total_kas'][$uniqueKey]) ? $report['total_kas'][$uniqueKey] : 0;
                                    $sub_total += $amount;
                                    $group_totals[$bulan] += $amount;
                                    $overall_totals[$bulan] += $amount;
                                    $tempTotalPerKelompok[$kelompok][$bulan] += $amount;
                                    
                                    // Ambil data anggaran
                                    $anggaranKey = $subkategori . "|" . $bulan;
                                    $anggaran = isset($report['anggaran_dict'][$anggaranKey]) ? $report['anggaran_dict'][$anggaranKey] : 0;
                                    $anggaran_total += $anggaran;
                                ?>
                                    <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($sub_total, 0, ',', '.') ?></td>
                                <td class="text-end">Rp <?= number_format($anggaran_total, 0, ',', '.') ?></td>
                                <td class="text-end fw-bold">Rp <?= number_format($sub_total - $anggaran_total, 0, ',', '.') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        
                        <!-- Tampilkan total kategori jika ada data -->
                        <?php if ($hasDataInCategory && isset($report['kategori_dict'][$kategori])): ?>
                            <?php
                            $kategori_total = 0;
                            ?>
                            <tr style="background-color: #92d050;">
                                <td><strong>Total <?= $kategori ?></strong></td>
                                <td></td>
                                <td></td>
                                <?php foreach ($report['bulan'] as $bulan): 
                                    $totalKey = $kategori . "|" . $bulan;
                                    $amount = isset($report['total_per_kategori_bulan'][$totalKey]) ? $report['total_per_kategori_bulan'][$totalKey] : 0;
                                    $kategori_total += $amount;
                                ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($kategori_total, 0, ',', '.') ?></td>
                                <td class="text-end"></td>
                                <td class="text-end fw-bold">Rp <?= number_format($kategori_total, 0, ',', '.') ?></td>
                            </tr>
                        <?php endif; ?>
                        
                    <?php endforeach; ?>
                    
                    <!-- Total kelompok terakhir -->
                    <?php if ($current_group !== ''): ?>
                        <?php
                        $hasDataInGroup = false;
                        $kelompok_total = 0;
                        
                        // Cek apakah ada data dalam kelompok ini
                        foreach ($report['bulan'] as $bulan) {
                            if ($tempTotalPerKelompok[$current_group][$bulan] > 0) {
                                $hasDataInGroup = true;
                                break;
                            }
                        }
                        
                        if ($hasDataInGroup):
                        ?>
                            <tr class="table-warning">
                                <td colspan="2"><strong>Total Kelompok <?= $current_group ?></strong></td>
                                <td></td>
                                <?php 
                                $kelompok_total = 0;
                                foreach ($report['bulan'] as $bulan): 
                                    $amount = $tempTotalPerKelompok[$current_group][$bulan] ?? 0;
                                    $kelompok_total += $amount;
                                ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($kelompok_total, 0, ',', '.') ?></td>
                                <td class="text-end"></td>
                                <td class="text-end fw-bold">Rp <?= number_format($kelompok_total, 0, ',', '.') ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endif; ?>
                    
                    <!-- Total keseluruhan -->
                    <tr class="table-primary">
                        <td colspan="2"><strong>TOTAL KESELURUHAN</strong></td>
                        <td></td>
                        <?php 
                        $grand_total = 0;
                        foreach ($report['bulan'] as $bulan): 
                            $amount = $overall_totals[$bulan] ?? 0;
                            $grand_total += $amount;
                        ?>
                            <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                        <?php endforeach; ?>
                        <td class="text-end fw-bold">Rp <?= number_format($grand_total, 0, ',', '.') ?></td>
                        <td class="text-end"></td>
                        <td class="text-end fw-bold">Rp <?= number_format($grand_total, 0, ',', '.') ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
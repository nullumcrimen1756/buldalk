<?php
require_once 'config.php';
require_once 'functions.php';

session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Set judul halaman
$page_title = "Input Transaksi - Sistem Keuangan Gereja";

$action = isset($_GET['action']) ? $_GET['action'] : 'form';

switch ($action) {
    case 'form':
        showForm();
        break;
    case 'submit':
        submitForm();
        break;
    case 'report':
        showReport();
        break;
    case 'sheet2_report':
        generateSheet2Report();
        include 'views/sheet2_report.php';
        break;
    case 'sheet3_report':
        generateSheet3Report();
        include 'views/sheet3_report.php';
        break;
    case 'get_kategori':
        getKategoriByJurnal();
        break;
    case 'get_subkategori':
        getSubkategori();
        break;
    default:
        showForm();
}

// Include header
include 'views/header.php';

// ... existing content ...

// Include footer
include 'views/footer.php';
?>